﻿using DarkHelpers.WPF;
using SomeNamespace.ViewModels;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : DarkWpfViewBase<SomeViewModel>
    {
        public $safeitemname$(SomeViewModel vm) : base(vm)
        {
            InitializeComponent();
        }
    }
}
