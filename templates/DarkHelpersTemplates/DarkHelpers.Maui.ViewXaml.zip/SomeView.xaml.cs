using DarkHelpers.Maui;
using Sample.Lib.ViewModels;

namespace $rootnamespace$;

public partial class $safeitemname$ : DarkMauiViewBase<SomeViewModel>
{
	public $safeitemname$(SomeViewModel vm) : base(vm)
	{
		InitializeComponent();
	}
}