﻿using DarkHelpers.XF;
using SomeNamespace.ViewModels;
using Xamarin.Forms.Xaml;

namespace $rootnamespace$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class $safeitemname$ : DarkXfViewBase<SomeViewModel>
    {
        public $safeitemname$(SomeViewModel vm) : base(vm)
        {
            InitializeComponent();
        }
    }
}