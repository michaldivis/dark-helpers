using DarkHelpers.Maui;

namespace SomeApp.Views;

public class $safeitemname$ : DarkMauiViewBase<SomeViewModel>
{
	public $safeitemname$(SomeViewModel vm) : base(vm)
	{
		Content = new VerticalStackLayout
		{
			Children = {
				new Label { Text = "Hey!" }
			}
		};
	}
}